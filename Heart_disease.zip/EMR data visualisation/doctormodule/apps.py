from django.apps import AppConfig


class DoctormoduleConfig(AppConfig):
    name = 'doctormodule'
